#!/usr/bin/env bash
# Problem 4: Address Book system with add/search/remove/display

ADDRESS_BOOK_FILE="address_book.csv"

# Initialize file with header if not present
if [[ ! -f "$ADDRESS_BOOK_FILE" ]]; then
  echo "Name,Surname,Email,Phone" > "$ADDRESS_BOOK_FILE"
fi

add_entry() {
  read -r -p "Name: " name
  read -r -p "Surname: " surname
  read -r -p "Email: " email
  read -r -p "Phone: " phone
  echo "You entered: $name,$surname,$email,$phone"
  read -r -p "Confirm adding this entry? (y/n): " confirm
  if [[ "$confirm" == "y" ]]; then
    echo "$name,$surname,$email,$phone" >> "$ADDRESS_BOOK_FILE"
    echo "Entry added."
  else
    echo "Entry discarded."
  fi
}

search_entry() {
  read -r -p "Search term: " term
  echo "Matching entries:"
  grep -in "$term" "$ADDRESS_BOOK_FILE"
}

remove_entry() {
  read -r -p "Search term to narrow down: " term
  echo "Matching entries:"
  grep -in "$term" "$ADDRESS_BOOK_FILE"
  read -r -p "Enter line number to remove (excluding header): " lineno
  if [[ "$lineno" =~ ^[0-9]+$ ]]; then
    line=$(sed -n "${lineno}p" "$ADDRESS_BOOK_FILE")
    echo "Selected: $line"
    read -r -p "Confirm removal? (y/n): " confirm
    if [[ "$confirm" == "y" ]]; then
      sed "${lineno}d" "$ADDRESS_BOOK_FILE" > tmp && mv tmp "$ADDRESS_BOOK_FILE"
      echo "Entry removed."
    else
      echo "Removal cancelled."
    fi
  else
    echo "Invalid line number."
  fi
}

display_all() {
  read -r -p "Enter filter (or press Enter to show all): " filter
  if [[ -z "$filter" ]]; then
    cat "$ADDRESS_BOOK_FILE"
  else
    grep -i "$filter" "$ADDRESS_BOOK_FILE"
  fi
}

# Main menu loop
while true; do
  echo
  echo "Address Book Menu:"
  echo "1) Add Entry"
  echo "2) Search Entry"
  echo "3) Remove Entry"
  echo "4) Display Records"
  echo "5) Exit"
  read -r -p "Enter your choice (1-5): " choice
  case $choice in
    1) add_entry ;;
    2) search_entry ;;
    3) remove_entry ;;
    4) display_all ;;
    5) echo "Goodbye!"; exit ;;
    *) echo "Invalid choice. Please enter 1–5." ;;
  esac
done