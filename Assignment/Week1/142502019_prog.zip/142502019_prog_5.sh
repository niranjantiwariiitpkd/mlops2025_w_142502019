#!/usr/bin/env bash
# Problem 5: Reverse a string
str="$1"
if [[ -z "$str" ]]; then
  read -r -p "Enter string: " str
fi
echo "$str" | rev
