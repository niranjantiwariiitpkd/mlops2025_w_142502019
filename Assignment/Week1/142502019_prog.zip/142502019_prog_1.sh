#!/usr/bin/env bash
# Problem 1: Quadratic roots of ax^2 + bx + c = 0

echo "Quadratic equation ax^2 + bx + c = 0"

# Read and validate inputs
read -r -p "Enter a (non-zero): " a
read -r -p "Enter b: " b
read -r -p "Enter c: " c

# Check if inputs are numeric
for var in "$a" "$b" "$c"; do
  if ! [[ "$var" =~ ^-?[0-9]+(\.[0-9]+)?$ ]]; then
    echo "Error: All coefficients must be numeric."
    exit 1
  fi
done

if [[ "$a" == "0" ]]; then
  echo "Coefficient 'a' must not be zero."
  exit 1
fi

# Compute discriminant
D=$(echo "scale=12; $b * $b - 4 * $a * $c" | bc -l)

# Check if D is negative or zero
is_neg=$(echo "$D < 0" | bc)
is_zero=$(echo "$D == 0" | bc)

if [[ "$is_neg" -eq 0 ]]; then
  sqrtD=$(echo "scale=12; sqrt($D)" | bc -l)
  denom=$(echo "scale=12; 2 * $a" | bc -l)
  x1=$(echo "scale=12; (-1 * $b + $sqrtD) / $denom" | bc -l)
  x2=$(echo "scale=12; (-1 * $b - $sqrtD) / $denom" | bc -l)

  if [[ "$is_zero" -eq 1 ]]; then
    echo "One real root (double): x = $x1"
  else
    echo "Two real roots: x1 = $x1, x2 = $x2"
  fi
else
  Dpos=$(echo "scale=12; -1 * $D" | bc -l)
  sqrtDpos=$(echo "scale=12; sqrt($Dpos)" | bc -l)
  denom=$(echo "scale=12; 2 * $a" | bc -l)
  real=$(echo "scale=12; -1 * $b / $denom" | bc -l)
  imag=$(echo "scale=12; $sqrtDpos / $denom" | bc -l)
  echo "Complex roots:"
  echo "x1 = ${real} + ${imag}i"
  echo "x2 = ${real} - ${imag}i"
fi