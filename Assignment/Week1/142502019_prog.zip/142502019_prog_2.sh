#!/usr/bin/env bash
# Problem 2: Traverse filesystem directories and list contents
start="${1:-/}"
depth="${2:-2}"
find "$start" -maxdepth "$depth" -type d -print0 2>/dev/null | \
while IFS= read -r -d '' d; do
  echo ">>> Directory: $d"
  if ! ls -A -- "$d" 2>/dev/null; then
    echo "(permission denied)"
  fi
  echo "------------------------------------------------"
done
