#!/usr/bin/env bash
# Problem 3: Reverse file contents using pr, sort, cut
file="$1"
if [[ -z "$file" || ! -f "$file" ]]; then
  echo "Usage: $0 file.txt"
  exit 1
fi
pr -n -t -w 9999 -- "$file" | sort -nr | cut -f2-
