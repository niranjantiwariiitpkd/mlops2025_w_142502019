import torch
import torchvision.models as models
import json
import toml

def load_model(variant):
    if variant == "resnet34":
        return models.resnet34(pretrained=True)
    elif variant == "resnet50":
        return models.resnet50(pretrained=True)
    elif variant == "resnet101":
        return models.resnet101(pretrained=True)
    elif variant == "resnet152":
        return models.resnet152(pretrained=True)
    else:
        raise ValueError("Unsupported ResNet variant")

# Load JSON and TOML configs
with open("config.json") as f:
    config = json.load(f)

params = toml.load("params.toml")

for arch in config["model_architectures"]:
    model = load_model(arch)
    lr = params[arch]["learning_rate"]
    opt = params[arch]["optimizer"]
    mom = params[arch]["momentum"]
    print(f"{arch}: lr={lr}, optimizer={opt}, momentum={mom}")